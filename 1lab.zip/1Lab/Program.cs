﻿maxReplaceMatrix matrix = new maxReplaceMatrix(); // Инициализация класса

matrix.fillingRandomMatrix(); // Наполнение случайными значениями

Console.WriteLine("Изначальная матрица");

matrix.printMatrix(); // Вывод изначальной матрицы
matrix.replaceMax(); // Замена максимальных значений местами 

Console.WriteLine("Конечная матрица");

matrix.printMatrix(); // Вывод матрицы с заменой максимальных значений




class maxReplaceMatrix {

    public int size = 5; // Размер квадратной матрицы
    public int[,]? matrix; // Матрица
    int[] maxLeft = new int[2] { 1, 0 }; // Массив для хранения индексов максимального значения слева от диагонали
    int[] maxRight = new int[2] { 0, 1 }; // Массив для хранения индексов максимального значения справа от диагонали


    // Метод для заполнения матрицы случайными значениями
    public void fillingRandomMatrix()
    {

        // Ввод одной из границ диапазона чисел
        Console.Write("Введите первую границу диапозона: ");
        string input = Console.ReadLine();
        int firstRange;
        bool isNumL = int.TryParse(input, out firstRange);
        
        // Проверка на число и запуск цикла, пока не будет введено число
        while(!isNumL)
        {
            Console.Write("Граница должна быть числом!!!\nВведите первую границу диапозона: ");
            input = Console.ReadLine();
            isNumL = int.TryParse(input, out firstRange);
        }
        Console.Write("Введите вторую границу диапозона: ");
        input = Console.ReadLine();
        int secondRange;

        bool isNumR = int.TryParse(input, out secondRange);
        while (!isNumR)
        {
            Console.Write("Граница должна быть числом!!!\nВведите вторую границу диапозона: ");
            input = Console.ReadLine();
            isNumR = int.TryParse(input, out secondRange);
        }

        //Проверка границ
        if (secondRange < firstRange)
        {
            // Замена местами, если правая граница меньше левой
            int temp = firstRange;
            firstRange = secondRange;
            secondRange = temp;
        }


        matrix = new int[size, size];

        Random rand = new Random();
        // Заполнение матрицы
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                matrix[i, j] = rand.Next(firstRange, secondRange);
            }
        }
    }


    // Метод замены максимальных значений местами 
    public int[,]? replaceMax()
    {
        // Проверка, что матрица была заполнена
        if(matrix == null || matrix.Length == 0)
        {
            return matrix;
        }
        //Поиск максимальных значений
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {

                if (i > 0 && j < i && matrix[maxLeft[0], maxLeft[1]] < matrix[i, j])
                {
                    maxLeft[0] = i;
                    maxLeft[1] = j;
                }
                else if (i < size && j > i && matrix[maxRight[0], maxRight[1]] < matrix[i, j])
                {
                    maxRight[0] = i;
                    maxRight[1] = j;
                }
            }
        }

        // Замена максимальных значений местами
        int temp = matrix[maxLeft[0], maxLeft[1]];
        matrix[maxLeft[0], maxLeft[1]] = matrix[maxRight[0], maxRight[1]];
        matrix[maxRight[0], maxRight[1]] = temp;

        return matrix;
    }


    // Метод вывода матрицы
    public void printMatrix()
    {
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {

                Console.Write("\t" + matrix[i, j]);
            }
            Console.Write("\n");
        }
    }
}