﻿namespace ChogiwaClient
{
    partial class Chogiwa
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.настройкиПодключенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productsDGV = new System.Windows.Forms.DataGridView();
            this.prodLabel = new System.Windows.Forms.Label();
            this.categoryCB = new System.Windows.Forms.ComboBox();
            this.getProds = new System.Windows.Forms.Button();
            this.deleteProdButton = new System.Windows.Forms.Button();
            this.prodId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.editProductButton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productsDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.настройкиПодключенияToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1051, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // настройкиПодключенияToolStripMenuItem
            // 
            this.настройкиПодключенияToolStripMenuItem.Name = "настройкиПодключенияToolStripMenuItem";
            this.настройкиПодключенияToolStripMenuItem.Size = new System.Drawing.Size(158, 20);
            this.настройкиПодключенияToolStripMenuItem.Text = "Настройки подключения";
            this.настройкиПодключенияToolStripMenuItem.Click += new System.EventHandler(this.настройкиПодключенияToolStripMenuItem_Click);
            // 
            // productsDGV
            // 
            this.productsDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.productsDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodId,
            this.prodName,
            this.price,
            this.category});
            this.productsDGV.Location = new System.Drawing.Point(38, 64);
            this.productsDGV.Name = "productsDGV";
            this.productsDGV.Size = new System.Drawing.Size(445, 205);
            this.productsDGV.TabIndex = 1;
            // 
            // prodLabel
            // 
            this.prodLabel.AutoSize = true;
            this.prodLabel.Location = new System.Drawing.Point(237, 48);
            this.prodLabel.Name = "prodLabel";
            this.prodLabel.Size = new System.Drawing.Size(46, 13);
            this.prodLabel.TabIndex = 2;
            this.prodLabel.Text = "Товары";
            // 
            // categoryCB
            // 
            this.categoryCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.categoryCB.FormattingEnabled = true;
            this.categoryCB.Location = new System.Drawing.Point(38, 283);
            this.categoryCB.Name = "categoryCB";
            this.categoryCB.Size = new System.Drawing.Size(121, 21);
            this.categoryCB.TabIndex = 3;
            // 
            // getProds
            // 
            this.getProds.Location = new System.Drawing.Point(165, 275);
            this.getProds.Name = "getProds";
            this.getProds.Size = new System.Drawing.Size(118, 66);
            this.getProds.TabIndex = 4;
            this.getProds.Text = "Получить список товаров";
            this.getProds.UseVisualStyleBackColor = true;
            this.getProds.Click += new System.EventHandler(this.getProds_Click);
            // 
            // deleteProdButton
            // 
            this.deleteProdButton.Location = new System.Drawing.Point(165, 347);
            this.deleteProdButton.Name = "deleteProdButton";
            this.deleteProdButton.Size = new System.Drawing.Size(118, 61);
            this.deleteProdButton.TabIndex = 5;
            this.deleteProdButton.Text = "Удалить товар";
            this.deleteProdButton.UseVisualStyleBackColor = true;
            this.deleteProdButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // prodId
            // 
            this.prodId.Frozen = true;
            this.prodId.HeaderText = "Id";
            this.prodId.Name = "prodId";
            this.prodId.ReadOnly = true;
            // 
            // prodName
            // 
            this.prodName.Frozen = true;
            this.prodName.HeaderText = "Название";
            this.prodName.Name = "prodName";
            this.prodName.ReadOnly = true;
            // 
            // price
            // 
            this.price.Frozen = true;
            this.price.HeaderText = "Цена";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            // 
            // category
            // 
            this.category.Frozen = true;
            this.category.HeaderText = "Категория";
            this.category.Name = "category";
            this.category.ReadOnly = true;
            // 
            // editProductButton
            // 
            this.editProductButton.Location = new System.Drawing.Point(289, 275);
            this.editProductButton.Name = "editProductButton";
            this.editProductButton.Size = new System.Drawing.Size(101, 66);
            this.editProductButton.TabIndex = 6;
            this.editProductButton.Text = "Редактировать";
            this.editProductButton.UseVisualStyleBackColor = true;
            this.editProductButton.Click += new System.EventHandler(this.editProductButton_Click);
            // 
            // Chogiwa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 642);
            this.Controls.Add(this.editProductButton);
            this.Controls.Add(this.deleteProdButton);
            this.Controls.Add(this.getProds);
            this.Controls.Add(this.categoryCB);
            this.Controls.Add(this.prodLabel);
            this.Controls.Add(this.productsDGV);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Chogiwa";
            this.ShowInTaskbar = false;
            this.Text = "mainForm";
            this.Load += new System.EventHandler(this.Chogiwa_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productsDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem настройкиПодключенияToolStripMenuItem;
        private System.Windows.Forms.DataGridView productsDGV;
        private System.Windows.Forms.Label prodLabel;
        private System.Windows.Forms.ComboBox categoryCB;
        private System.Windows.Forms.Button getProds;
        private System.Windows.Forms.Button deleteProdButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodId;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodName;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn category;
        private System.Windows.Forms.Button editProductButton;
    }
}

