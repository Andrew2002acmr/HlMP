﻿
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ChogiwaClient
{
    public partial class loginForm : Form
    {

        private Chogiwa chogiwaMain;
        public loginForm(Chogiwa chogiwa)
        {

            chogiwaMain = chogiwa;
            InitializeComponent();
        }

        private async void signInButton_Click(object sender, EventArgs e)
        {
            string email = emailInput.Text;
            string password = passwordInput.Text;
            string port = Chogiwa.port;
            string data;
            


            var baseAddress = new Uri("https://localhost:7061");

            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("email", email),
                new KeyValuePair<string, string>("password", password)
            });

            HttpClient client = new HttpClient();

            HttpResponseMessage resp = await client.PostAsync(baseAddress + "api/Login", content);
            
           
            data = await resp.Content.ReadAsStringAsync();
            var authInfo = JObject.Parse(data);
            Console.WriteLine(Convert.ToString(authInfo["statusCode"]));
            if (Convert.ToString(authInfo["statusCode"]) != "400")
            {
                Chogiwa.authToken = Convert.ToString(authInfo["value"]["access_token"]);
                Chogiwa.role = Convert.ToString(authInfo["value"]["role"]);


                chogiwaMain.addAdminPanel();
                chogiwaMain.fillCategory();
                chogiwaMain.Opacity = 1;
                chogiwaMain.ShowInTaskbar = true;
                Close();
            }
            else
            {
                MessageBox.Show("Неверные данные");
            }


           

        }
    }
}
