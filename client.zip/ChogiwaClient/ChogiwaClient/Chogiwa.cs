﻿using ChogiwaClient.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ChogiwaClient
{
    public partial class Chogiwa : Form
    {
        public static string port = "";
        public static HttpClient client = new HttpClient();
        public static string authToken;
        public static string role;
        private List<Products> prods = new List<Products>();

        public Chogiwa()
        {
            InitializeComponent();
            
        }

        private void настройкиПодключенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConnectionForm connectionForm = new ConnectionForm(this);
            connectionForm.Show();
        }

        private void adminPanel_Click(object sender, EventArgs e)
        {

            adminPanel adminPanelForm = new adminPanel();
            adminPanelForm.Show();
        }

        public void addAdminPanel()
        {
            ToolStripMenuItem adminPanel = new ToolStripMenuItem("Администрирование", null, new EventHandler(adminPanel_Click));
        
            menuStrip1.Items.Add(adminPanel); 
            

        }

        public async void fillCategory()
        {
            HttpClient client = Chogiwa.client;
            string authToken = Chogiwa.authToken;
            string data;
            var baseAddress = new Uri("https://localhost:7061");

            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + authToken);

            HttpResponseMessage resp = await client.GetAsync(baseAddress + "api/prodCategory");


            data = await resp.Content.ReadAsStringAsync();
            var categories = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(data);
            for (int i= 0; i < categories.Count; i++)
            {
                categoryCB.Items.Add(categories[i]["name"]);
            }


          
        }

        private void Chogiwa_Load(object sender, EventArgs e)
        {
            this.Opacity = 0;
            loginForm loginForm = new loginForm(this);
            loginForm.Show();
        }

        private async void getProds_Click(object sender, EventArgs e)
        {
            getProds.Enabled = false;

            HttpClient client = Chogiwa.client;
            string authToken = Chogiwa.authToken;
            string data;
            var baseAddress = new Uri("https://localhost:7061");
/*
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + authToken);*/

            HttpResponseMessage resp = await client.GetAsync(baseAddress + "api/Product");


            data = await resp.Content.ReadAsStringAsync();
            prods = JsonConvert.DeserializeObject<List<Products>>(data);

            if (categoryCB.Text != "")
            {
                List<Products> prodByCategory = new List<Products>();
                for (int i = 0; i < prods.Count; i++)
                {
                    if (prods[i].category["name"] == categoryCB.Text)
                    {

                        prodByCategory.Add(prods[i]);
                    }
                }
                productsDGV.RowCount = prodByCategory.Count;
                for (int i = 0; i < prodByCategory.Count; i++)
                {
                    productsDGV[0, i].Value = prodByCategory[i].Id;
                    productsDGV[1, i].Value = prodByCategory[i].ProductName;
                    productsDGV[2, i].Value = prodByCategory[i].Price;
                    productsDGV[3, i].Value = prodByCategory[i].category["name"];
                }

            }


            getProds.Enabled = true;
        }

        private async void button1_Click(object sender, EventArgs e)
        {


            getProds.Enabled = false;

            HttpClient client = Chogiwa.client;
            string authToken = Chogiwa.authToken;
            string data;
            var baseAddress = new Uri("https://localhost:7061");


            HttpResponseMessage resp = await client.DeleteAsync(baseAddress + "api/Product/" + productsDGV[0, productsDGV.SelectedCells[0].RowIndex].Value);
               
            if(resp.StatusCode != System.Net.HttpStatusCode.OK)
            {
                MessageBox.Show("У вас не достаточно прав!");
            }
            else
            {
                productsDGV.Rows.Remove(productsDGV.Rows[productsDGV.SelectedCells[0].RowIndex]);
            }

            getProds.Enabled = true;
        }

        private void editProductButton_Click(object sender, EventArgs e)
        {
            var prodId = productsDGV[0, productsDGV.SelectedCells[0].RowIndex].Value;
            var category = productsDGV[3, productsDGV.SelectedCells[0].RowIndex].Value;
            editProductForm.prodId = prodId.ToString();
            editProductForm.category = category.ToString();
            editProductForm editProd = new editProductForm();
            editProd.Show();
        }
    }
}
