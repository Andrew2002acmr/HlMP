﻿namespace ChogiwaClient
{
    partial class adminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ages = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.post_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.secondName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fristName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.empsLabel = new System.Windows.Forms.Label();
            this.empsButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ages
            // 
            this.ages.Frozen = true;
            this.ages.HeaderText = "Возраст";
            this.ages.Name = "ages";
            this.ages.ReadOnly = true;
            // 
            // sex
            // 
            this.sex.Frozen = true;
            this.sex.HeaderText = "Пол";
            this.sex.Name = "sex";
            this.sex.ReadOnly = true;
            // 
            // post_name
            // 
            this.post_name.Frozen = true;
            this.post_name.HeaderText = "Должность";
            this.post_name.Name = "post_name";
            this.post_name.ReadOnly = true;
            // 
            // salary
            // 
            this.salary.Frozen = true;
            this.salary.HeaderText = "Зар-плата";
            this.salary.Name = "salary";
            this.salary.ReadOnly = true;
            // 
            // secondName
            // 
            this.secondName.Frozen = true;
            this.secondName.HeaderText = "Фамилия";
            this.secondName.Name = "secondName";
            this.secondName.ReadOnly = true;
            // 
            // fristName
            // 
            this.fristName.Frozen = true;
            this.fristName.HeaderText = "Имя";
            this.fristName.Name = "fristName";
            this.fristName.ReadOnly = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fristName,
            this.secondName,
            this.salary,
            this.post_name,
            this.sex,
            this.ages});
            this.dataGridView1.Location = new System.Drawing.Point(12, 49);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(652, 204);
            this.dataGridView1.TabIndex = 4;
            // 
            // empsLabel
            // 
            this.empsLabel.AutoSize = true;
            this.empsLabel.Location = new System.Drawing.Point(12, 29);
            this.empsLabel.Name = "empsLabel";
            this.empsLabel.Size = new System.Drawing.Size(32, 13);
            this.empsLabel.TabIndex = 5;
            this.empsLabel.Text = "emps";
            // 
            // empsButton
            // 
            this.empsButton.Location = new System.Drawing.Point(12, 259);
            this.empsButton.Name = "empsButton";
            this.empsButton.Size = new System.Drawing.Size(318, 43);
            this.empsButton.TabIndex = 6;
            this.empsButton.Text = "Получить список сотрудников";
            this.empsButton.UseVisualStyleBackColor = true;
            this.empsButton.Click += new System.EventHandler(this.empsButton_Click);
            // 
            // adminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.empsButton);
            this.Controls.Add(this.empsLabel);
            this.Controls.Add(this.dataGridView1);
            this.Name = "adminPanel";
            this.Text = "adminPanel";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn ages;
        private System.Windows.Forms.DataGridViewTextBoxColumn sex;
        private System.Windows.Forms.DataGridViewTextBoxColumn post_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn salary;
        private System.Windows.Forms.DataGridViewTextBoxColumn secondName;
        private System.Windows.Forms.DataGridViewTextBoxColumn fristName;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label empsLabel;
        private System.Windows.Forms.Button empsButton;
    }
}