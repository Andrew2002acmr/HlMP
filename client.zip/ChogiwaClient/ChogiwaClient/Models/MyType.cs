﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChogiwaClient.Models
{
    internal class MyType
    {
        public string key { get; set; }
        public Dictionary<string, string> product { get; set; }
    }
}
