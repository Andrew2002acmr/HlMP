﻿namespace ChogiwaClient
{
    partial class editProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.prodEditDGV = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.prodEditDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // prodEditDGV
            // 
            this.prodEditDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prodEditDGV.Location = new System.Drawing.Point(12, 25);
            this.prodEditDGV.Name = "prodEditDGV";
            this.prodEditDGV.Size = new System.Drawing.Size(492, 207);
            this.prodEditDGV.TabIndex = 0;
            // 
            // editProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.prodEditDGV);
            this.Name = "editProductForm";
            this.Text = "editProductForm";
            this.Load += new System.EventHandler(this.editProductForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.prodEditDGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView prodEditDGV;
    }
}