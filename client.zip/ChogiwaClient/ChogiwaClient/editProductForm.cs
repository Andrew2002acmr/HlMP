﻿using ChogiwaClient.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChogiwaClient
{
    public partial class editProductForm : Form
    {
        public static string prodId;
        public static string category;
        public editProductForm()
        {
            InitializeComponent();
        }

        private void editProductForm_Load(object sender, EventArgs e)
        {

            getDetailProd();

        }

        private async void getDetailProd()
        {
            HttpClient client = Chogiwa.client;

            string data;
            var baseAddress = new Uri("https://localhost:7061");


            HttpResponseMessage resp = await client.GetAsync(baseAddress + "api/" + category + "/" + prodId );

            data = await resp.Content.ReadAsStringAsync();

            JObject prods = JObject.Parse(data);
            IList<string> keysDetail = prods.Properties().Select(p => p.Name).ToList();
           
            prodEditDGV.Columns.Clear();
            for(int i = 0; i < keysDetail.Count; i++)
            {
                if(keysDetail[i] != "products" && keysDetail[i] != "id" && keysDetail[i] != "productId")
                {
                    prodEditDGV.Columns.Add(keysDetail[i], keysDetail[i]);
                }
            }
        }
    }
}
