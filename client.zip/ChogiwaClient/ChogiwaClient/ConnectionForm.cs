﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChogiwaClient
{
    public partial class ConnectionForm : Form
    {
        private Chogiwa chogiwaMain;
        public ConnectionForm(Chogiwa chogiwa)
        {
            chogiwaMain = chogiwa;
            InitializeComponent();
        }

        private void подключитьсяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string PORT = portInput.Text;

            Chogiwa.port = PORT;

            loginForm loginForm = new loginForm(chogiwaMain);
           
            loginForm.Show();
            this.Close();
        }
    }
}
