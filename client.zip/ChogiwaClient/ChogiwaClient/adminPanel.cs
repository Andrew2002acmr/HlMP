﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChogiwaClient
{
    public partial class adminPanel : Form
    {
        public adminPanel()
        {
            InitializeComponent();
        }

        private async void empsButton_Click(object sender, EventArgs e)
        {
            HttpClient client = Chogiwa.client;
            string authToken = Chogiwa.authToken;
            string data;
            var baseAddress = new Uri("https://localhost:7061");

            /* var content = new FormUrlEncodedContent(new[]
             {
                 new KeyValuePair<string, string>("email", email),
                 new KeyValuePair<string, string>("password", password)
             });*//*
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + authToken);*/

            HttpResponseMessage resp = await client.GetAsync(baseAddress + "api/Emps");


            data = await resp.Content.ReadAsStringAsync();
            var emps = JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(data);

            dataGridView1.RowCount = emps.Count;
            for (int i = 0; i < emps.Count; i++)
            {
                dataGridView1[0, i].Value = emps[i]["firstName"];
                dataGridView1[1, i].Value = emps[i]["surname"];
                dataGridView1[2, i].Value = emps[i]["salary"];
                dataGridView1[3, i].Value = emps[i]["post_name"];
                dataGridView1[4, i].Value = emps[i]["sex"];
                dataGridView1[5, i].Value = emps[i]["ages"];

            }

        }
    }
}
